export default [
  {
    header: 'Apps & Pages',
  },
  {
    title: 'Email',
    route: 'apps-email',
    icon: 'MailIcon',
  },
  {
    title: 'Chat',
    route: 'apps-chat',
    icon: 'MessageSquareIcon',
  },
  {
    title: 'Blog',
    children: [
      {
        title: 'List',
        route: 'pages-blog-list',
      },
      {
        title: 'Detail',
        route: { name: 'pages-blog-detail', params: { id: 1 } },
      },
      {
        title: 'Edit',
        route: { name: 'pages-blog-edit', params: { id: 1 } },
      },
    ],
  },
]
